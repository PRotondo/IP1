public class Automate1D {

  public static boolean[] front = {};
  public static boolean[] back  = {};

  public static char black = '█';
  public static char white = ' ';

  // Écrivez vos fonctions ici

  public static void main(String[] args) {
    // Écrivez vos tests ici
  }
}
